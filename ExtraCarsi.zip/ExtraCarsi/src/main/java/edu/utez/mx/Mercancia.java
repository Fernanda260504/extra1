package edu.utez.mx;

public class Mercancia {
    private int peso ;
    private int distancia ;
    private String transporte ;

    public Mercancia() {
    }

    public Mercancia(int peso, int distnacia, String transporte) {
        this.peso = peso;
        this.distancia = distnacia;
        this.transporte = transporte;
    }

    public int getPeso() {
        return peso;
    }

    public void setPeso(int peso) {
        this.peso = peso;
    }

    public int getDistnacia() {
        return distancia;
    }

    public void setDistnacia(int distnacia) {
        this.distancia = distnacia;
    }

    public String getTransporte() {
        return transporte;
    }

    public void setTransporte(String transporte) {
        this.transporte = transporte;
    }
    public boolean pesoPositivo (int peso,int distancia ,String transporte ){
        if(peso>=0 ){
            Mercancia merca =new Mercancia(peso,distancia,transporte);
            merca.setPeso(peso);
            merca.setDistnacia(distancia);
            merca.setTransporte(transporte);
            System.out.println("Datos correctos");
        }else {
            System.out.println("Datos incorrectos,peso negativo");
        }
        return true;

    }
    public boolean distanciaPositivo (int peso,int distancia ,String transporte ){
        if(distancia>=0){
            Mercancia merca =new Mercancia(peso,distancia,transporte);
            merca.setPeso(peso);
            merca.setDistnacia(distancia);
            merca.setTransporte(transporte);
            System.out.println("Datos correctos");
        }else {
            System.out.println("Datos incorrectos,distancia negativa");
        }
        return true;


    }

    public boolean costoMenorTerrestre(int peso,int distancia,String transporte){
        if(peso<=100 && transporte.equals("Terrestre") ){
           Mercancia merca = new Mercancia(peso,distancia,transporte);
           merca.setPeso(peso);
           merca.setDistnacia(distancia);
           merca.setTransporte(transporte);
            System.out.println("El costo de envío es de 50 pesos por kilogramo" );
        }else{
            System.out.println("El transporte no es terrestre,son mas kilogramos");
        }

return true;
    }
    public boolean costoMayorTerrestre(int peso,int distancia,String transporte){
        if(peso>100 && transporte.equals("Terrestre") ){
            Mercancia merca = new Mercancia(peso,distancia,transporte);
            merca.setPeso(peso);
            merca.setDistnacia(distancia);
            merca.setTransporte(transporte);
            System.out.println("El costo de envío es de 40 pesos por kilogramo" );
        }else{
            System.out.println("El transporte no es terrestre,son menos kilogramos");
        }

        return true;
    }
//Transporte Maritimo
    public boolean costoMenorMaritimo(int peso,int distancia,String transporte){
        if(peso<=500 && transporte.equals("Marítimo") ){
            Mercancia merca = new Mercancia(peso,distancia,transporte);
            merca.setPeso(peso);
            merca.setDistnacia(distancia);
            merca.setTransporte(transporte);
            System.out.println("El costo de envío es de 100 pesos por kilogramo" );
        }else{
            System.out.println("El transporte no es maritimo,son mas kilogramos");
        }

        return true;
    }


    public boolean costoMayorMaritimo(int peso,int distancia,String transporte){
        if(peso>500 && transporte.equals("Marítimo") ){
            Mercancia merca = new Mercancia(peso,distancia,transporte);
            merca.setPeso(peso);
            merca.setDistnacia(distancia);
            merca.setTransporte(transporte);
            System.out.println("El costo de envío es de 80 pesos por kilogramo" );
        }else{
            System.out.println("El transporte no es maritimo,menos kilogramos");
        }

        return true;
    }

    //Transporte Aéreo (Sin importr el peso)
    public boolean sinPesoAereo(int peso,int distancia,String transporte){
        if(transporte.equals("Aéreo") ){
            Mercancia merca = new Mercancia(peso,distancia,transporte);
            merca.setPeso(peso);
            merca.setDistnacia(distancia);
            merca.setTransporte(transporte);
            System.out.println("El costo de envío es de 200 pesos por kilogramo" );
        }else{
            System.out.println("El transporte no es  aéreo");
        }

        return true;
    }

}
