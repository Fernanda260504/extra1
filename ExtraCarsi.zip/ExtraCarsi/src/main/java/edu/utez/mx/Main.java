package edu.utez.mx;

import java.util.ArrayList;
import java.util.List;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
      Logistica logistica =new Logistica();
        logistica.setId(logistica.getId());
        logistica.setFecha(logistica.getFecha());
        logistica.setTipo_transporte(logistica.getTipo_transporte());
        logistica.setPeso_mercancia(logistica.getPeso_mercancia());
        logistica.setCosto_envio(logistica.getCosto_envio());

        List<Logistica> logisticas = new ArrayList<>();
        logisticas.get(1);

    }
}