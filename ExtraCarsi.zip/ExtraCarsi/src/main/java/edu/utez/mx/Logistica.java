package edu.utez.mx;

import java.util.ArrayList;
import java.util.List;

public class Logistica {
    private Long id;
    private String fecha;
    private String tipo_transporte;
    private int peso_mercancia;
    private int costo_envio;


    public Logistica() {
    }

    public Logistica(Long id, String fecha, String tipo_transporte, int peso_mercancia, int costo_envio) {
        this.id = id;
        this.fecha = fecha;
        this.tipo_transporte = tipo_transporte;
        this.peso_mercancia = peso_mercancia;
        this.costo_envio = costo_envio;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getTipo_transporte() {
        return tipo_transporte;
    }

    public void setTipo_transporte(String tipo_transporte) {
        this.tipo_transporte = tipo_transporte;
    }

    public int getPeso_mercancia() {
        return peso_mercancia;
    }

    public void setPeso_mercancia(int peso_mercancia) {
        this.peso_mercancia = peso_mercancia;
    }

    public int getCosto_envio() {
        return costo_envio;
    }

    public void setCosto_envio(int costo_envio) {
        this.costo_envio = costo_envio;
    }

}
