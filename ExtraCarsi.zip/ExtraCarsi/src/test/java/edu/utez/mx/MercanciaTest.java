package edu.utez.mx;

import org.junit.Test;

import static org.junit.Assert.*;

public class MercanciaTest {
    //
    @Test
    public void test1(){
   Mercancia mercancia=new Mercancia();
    assertTrue(mercancia.pesoPositivo(65,1004,"Aereo"));
    }
    @Test
    public void test2(){
        Mercancia mercancia=new Mercancia();
        assertTrue(mercancia.distanciaPositivo(65,1004,"Aereo"));
    }
    //Trasporte Terrestre
    @Test
    public void test3(){
        Mercancia mercancia= new Mercancia();
        assertTrue(mercancia.costoMenorTerrestre(65,1004,"Terrestre"));
    }
   @Test
    public void test4(){
        Mercancia merca = new Mercancia ();
        assertTrue(merca.costoMayorTerrestre(200,1004,"Terrestre"));
}
//Tranporte Maritimo
   @Test
    public void test5(){
        Mercancia merca =new Mercancia();
        assertTrue(merca.costoMenorMaritimo(200,1004,"Marítimo"));
    }
    @Test
    public void test6(){
        Mercancia merca = new Mercancia();
        assertTrue(merca.costoMayorMaritimo(1000,1004,"Marítimo"));
    }
    @Test
    public void test7(){
        Mercancia merca = new Mercancia();
        assertTrue(merca.sinPesoAereo(100,1004,"Aéreo"));
    }

}